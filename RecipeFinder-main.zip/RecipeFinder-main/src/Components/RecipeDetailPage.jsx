import React from 'react'

function RecipeDetailPage() {
  return (
<>


</>  )
}

export default RecipeDetailPage